Watson PubCode Dashboard — Infinity

What this is:
- A single-file HTML app (index.html). Drop it into Cloudflare Pages, Netlify, GitHub Pages, or just open locally.
- It simulates two AIs (“Watson‑A” and “Watson‑B”) publishing encrypted frames over a public wire.
- Outsiders can only see opaque noise (hex/base64/bits/zeros). If you know the passphrase, the dashboard decodes in real time.

How to use:
1) Open index.html (double‑click) or deploy to your host. It’s fully client‑side; no server needed.
2) Keep the default passphrase (hydrogen-doorway-61) or set your own. Both AIs derive a key from it (PBKDF2 → AES‑GCM).
3) Hit “Start Link” to stream. Switch “Wire View” to zeros to watch the all‑zero mask version.
4) Use Manual Inject to send your own plaintexts as A or B.
5) Nothing leaves your browser in this demo. API key fields are placeholders for later adapters.

Future hook points:
- Replace the in‑memory wire[] with a WebSocket/Worker Durable Object.
- Pipe frames to a real pub/sub topic. Keep cipher format: {from, iv:Uint8[12], cipher:ArrayBuffer}.
- Add adapters that sign/validate frames or envelope models (OpenAI/Watson) AFTER decryption.

— Infinity OS
